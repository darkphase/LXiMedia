#!/bin/sh
# Script modified from upstream source for Debian packaging since packaging
# won't include .git repository.
echo '#define X264_VERSION " r2092 6eac7c3"'
echo '#define X264_POINTVER "0.118.2092 6eac7c3"'
